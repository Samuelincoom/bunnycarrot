<?php

class carrot_bunnycdn_incoom_plugin_Manifest {
	/**
	 * @var array
	 */
	public $objects = array();
}